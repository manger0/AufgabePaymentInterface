package com.company;

public class Cash extends Account {
}
