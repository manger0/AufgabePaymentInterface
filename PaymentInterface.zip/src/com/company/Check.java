package com.company;

public class Check extends Account {
}
