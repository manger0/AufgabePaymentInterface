package com.company;

public class Debitcard extends Account {
}
